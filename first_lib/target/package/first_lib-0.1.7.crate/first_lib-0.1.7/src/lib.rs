pub fn table_function(mut add_number:u64,mut count_1:u64) {

loop { 
    println!(" 2 * {} = {}",count_1, add_number);
    count_1 = count_1 +1 ;
    add_number = add_number +2;
    if count_1 ==11  {
        break
    }

} 
}