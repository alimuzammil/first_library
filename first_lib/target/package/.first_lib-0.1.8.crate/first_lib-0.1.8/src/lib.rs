pub fn table_function(mut table:u64,mut count_1:u64) {

loop { 
    println!(" {} * {} = {}",table , count_1, add_number);
    count_1 = count_1 +1 ;
    add_number = table+table;
    if count_1 ==11  {
        break
    }

} 
}